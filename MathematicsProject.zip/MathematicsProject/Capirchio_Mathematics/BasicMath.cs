﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capirchio_Mathematics
{
    public class BasicMath
    {
        public double AddNumbers(double num1, double num2)
        {
            return num1 + num2;
        }

        public double SubtractNumbers(double num1, double num2)
        {
            return num1 - num2;
        }

        public double MultiplyNumbers(double num1, double num2)
        {
            return num1 * num2;
        }

        public double DivideNumbers(double num1, double num2)
        {
            return num1 / num2;
        }
    }
}
