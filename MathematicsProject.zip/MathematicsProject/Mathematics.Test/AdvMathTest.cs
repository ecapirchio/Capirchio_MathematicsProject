﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capirchio_Mathematics;

namespace Capirchio_Mathematics.Tests
{
    public class AdvMathTests
    {
        private readonly AdvMath advMath;

        public AdvMathTests()
        {
            advMath = new AdvMath();
        }

        [Fact]
        public void TestCalculateArea()
        {
            double height = 5;
            double width = 10;
            double result = advMath.CalculateArea(height, width);
            Assert.Equal(50, result);
        }

        [Fact]
        public void TestCalculateAverage()
        {
            var values = new List<double> { 10, 20, 30, 40 };
            double result = advMath.CalculateAverage(values);
            Assert.Equal(25, result);
        }

        [Fact]
        public void TestCalculateAverage_EmptyList_ThrowsException()
        {
            var values = new List<double>();
            Assert.Throws<ArgumentException>(() => advMath.CalculateAverage(values));
        }

        [Fact]
        public void TestCalculateSquared()
        {
            double value = 4;
            double result = advMath.CalculateSquared(value);
            Assert.Equal(16, result);
        }

        [Fact]
        public void TestCalculateHypotenuse()
        {
            double a = 3;
            double b = 4;
            double result = advMath.CalculateHypotenuse(a, b);
            Assert.Equal(5, result);
        }
    }
}
